# Fixtures do importador — GCS (.gct / .gcs / .gcs.txt / _gurps.json)

Pacote de amostras reais para calibrar e testar o importador previsto na v0.7.2 do kit Singular.

Conteúdo:
- `gct_racas_metas/` — 23 templates exportados pelo GCS (5 raças + 18 meta-características), versão de dados 2, nomes restaurados a partir do conteúdo interno (byte-a-byte idênticos aos originais).
- `amostras/gcs_sheets/` — 4 saves de ficha (.gcs, dados versão 5): Little Mouse, PC - Kadda La, Twig-Eater, Wooly Rhino.
- `amostras/Homem-Zebra-PT.gcs.txt` — export JSON tipo "character" v2 (apesar do sufixo .txt).
- `amostras/ALDRIC DE BOSSONIA_gurps (1) (1).json` — formato externo não-GCS (guardar cru; origem a identificar).

Regras de uso: tratar nomes de arquivo apenas como rótulo humano; nunca descartar campos desconhecidos; preservar UUIDs/TIDs como chave. Ver `Analise_formato_GCT.md` (§§15–17) para a especificação completa.

Gerado em 27/11/2026 a partir dos pacotes enviados pelo dono dos dados.

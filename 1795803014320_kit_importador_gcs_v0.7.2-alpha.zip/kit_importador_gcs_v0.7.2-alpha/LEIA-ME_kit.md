# Kit Importador GCS — v0.7.2-beta (implementação de referência)

Pacote autocontido do importador previsto na v0.7.2 do kit Singular, agora em **duas fases**:
- **Fase 1** — templates `.gct` (raças e meta-características);
- **Fase 2** — fichas completas `.gcs` (saves do GCS) e exports `character` (`.gcs.txt`).

Regras R1–R24 implementadas conforme `docs/Analise_formato_GCT.md` (§§12–19). O formato externo (`_gurps.json`, ecossistema Singular/plataforma irmã) é detectado e sinalizado como fora do escopo — sem perder bytes (registro cru preservado).

## Conteúdo
- `importador/importador_gct.py` — o importador (Python 3.9+, stdlib apenas).
- `docs/Analise_formato_GCT.md` — especificação completa do formato + recomendações.
- `docs/catalogo_amostras_adicionais.csv` — ficha técnica das amostras adicionais.
- `exemplos/` — saída real da rodada de calibração (relatório + JSONs canônicos de todas as fases).
- `amostras/fixtures_importador_gcs_v1.zip` — os 30 arquivos de teste originais.

## Uso
```
python3 importador/importador_gct.py <arquivo|pasta|zip> [...] [--out DIR]

# Selftest completo (suíte A: corpus .gct congelado; suíte B: amostras adicionais):
python3 importador/importador_gct.py amostras/fixtures_importador_gcs_v1.zip --selftest
```
Envelopes são detectados pela assinatura estrutural (nunca pelo nome/extensão); pasta ou ZIP, tanto faz (R12/R13/R21).

Saídas: `relatorio_importacao.md` (visão geral por arquivo/fase, avisos agrupados) e
`canonicos/<nome>.json` (um por template/ficha, com cópia crua preservada para auditoria — R9).

Códigos de saída: 0 = limpo; 2 = houve erros registrados no relatório.

## Métricas canônicas (fixture v1 + amostras)
- “Itens” conta todos os níveis recursivos; “itens internos” subtrai os contêineres-raiz (181 nos `.gct`; métrica idem nas fichas).
- “Features” contam listas de itens e de modificadores (212 no fixture v1 dos `.gct`).
- Deduplicação/merge: política definida pelo dono dos dados — **sempre perguntar ao usuário** (R11).

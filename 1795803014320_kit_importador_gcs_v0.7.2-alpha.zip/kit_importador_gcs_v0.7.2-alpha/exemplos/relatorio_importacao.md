# Relatório de importação — acervo GCS (.gct/.gcs/.gcs.txt)

> Gerado pelo `importador_gct.py` (referência v0.7.2 do kit Singular).

## Visão geral

- Arquivos processados: **29**

- Convertidos: **28** (fase 1: **23** · fase 2: **5**) · Fora do escopo: **1** · Erros fatais: **0**

- Equipamentos: **17** · Notas de ficha: **1**

- Itens (**todos os níveis, recursivo**): **267** — **75** contêineres-raiz + **192** itens internos

- Modificadores: **967** (desabilitados mantidos como opção: **846**)

- Features: **277** (desconhecidas preservadas cru: **0**)

- Armas: **42** · Skills de raiz: **46** · Defaults de skill: **131**

- Pré-requisitos: **9** · Placeholders `@…@`: **196**


## Por arquivo

| Nome | Ref. | Tipo | Versão | Família | Itens | Escopo |
|---|---|---:|---:|---|---:|---|

| Anão | B261 | raça | 2 | template_legacy | 6 | fase 1 |

| Dragão (Básico) | B261 | raça | 2 | template_legacy | 20 | fase 1 |

| Elfo | B316 | raça | 2 | template_legacy | 9 | fase 1 |

| Felinoide | B261 | raça | 2 | template_legacy | 15 | fase 1 |

| Jake Baker |  | personagem | 2 | character_export | 17 | fase 2 |

| Kadda La |  | ficha | 5 | sheet_gcs | 14 | fase 2 |

| Little Mouse |  | ficha | 5 | sheet_gcs | 6 | fase 2 |

| Metacaracterística: Animal Doméstico | B263 | meta | 2 | template_legacy | 5 | fase 1 |

| Metacaracterística: Animal Selvagem | B263 | meta | 2 | template_legacy | 5 | fase 1 |

| Metacaracterística: Autômato | B263 | meta | 2 | template_legacy | 6 | fase 1 |

| Metacaracterística: Corpo de Ar | B263 | meta | 2 | template_legacy | 9 | fase 1 |

| Metacaracterística: Corpo de Fogo | B263 | meta | 2 | template_legacy | 9 | fase 1 |

| Metacaracterística: Corpo de Gelo | B263 | meta | 2 | template_legacy | 13 | fase 1 |

| Metacaracterística: Corpo de Metal | B263 | meta | 2 | template_legacy | 8 | fase 1 |

| Metacaracterística: Corpo de Pedra | B263 | meta | 2 | template_legacy | 9 | fase 1 |

| Metacaracterística: Corpo de Terra | B263 | meta | 2 | template_legacy | 9 | fase 1 |

| Metacaracterística: Corpo de Água | B263 | meta | 2 | template_legacy | 10 | fase 1 |

| Metacaracterística: Entidade Astral | B262 | meta | 2 | template_legacy | 8 | fase 1 |

| Metacaracterística: Espírito | B262 | meta | 2 | template_legacy | 8 | fase 1 |

| Metacaracterística: Ictioide | B263 | meta | 2 | template_legacy | 3 | fase 1 |

| Metacaracterística: Inteligência Artificial | B263 | meta | 2 | template_legacy | 7 | fase 1 |

| Metacaracterística: Máquina | B262 | meta | 2 | template_legacy | 7 | fase 1 |

| Metacaracterística: Quadrúpede | B263 | meta | 2 | template_legacy | 4 | fase 1 |

| Metacaracterística: Vermiforme | B263 | meta | 2 | template_legacy | 4 | fase 1 |

| Metacaracterística: Veículo Terrestre | B263 | meta | 2 | template_legacy | 5 | fase 1 |

| Twig-Eater |  | ficha | 5 | sheet_gcs | 5 | fase 2 |

| Vampiro | B262 | raça | 2 | template_legacy | 25 | fase 1 |

| Wooly Rhino |  | ficha | 5 | sheet_gcs | 21 | fase 2 |


## Avisos agrupados

| Código | Nível | Ocorrências |
|---|---|---:|

| mod_desabilitado | info | 846 |

| placeholders_presentes | info | 21 |

| fora_do_escopo | warn | 1 |


**Legenda:**

- `mod_desabilitado` — modificador marcado `disabled:true` — preservado como opção desmarcada (R3).

- `placeholders_presentes` — marcações `@…@` — preservadas cru no texto (R7).

- `fora_do_escopo` — arquivo não pertence às famílias suportadas na v0.7.2.


## Arquivos fora do escopo v0.7.2

- `ALDRIC DE BOSSONIA_gurps (1) (1).json` — família `externo_singular`
